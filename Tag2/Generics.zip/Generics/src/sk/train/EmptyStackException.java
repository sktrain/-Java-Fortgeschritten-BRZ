package sk.train;

public class EmptyStackException extends IllegalStateException {
}
