package sk.train;

@SuppressWarnings("serial")
public class IllegalStrategyException extends RuntimeException {

	public IllegalStrategyException() {
		super();
	}

	public IllegalStrategyException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public IllegalStrategyException(String message, Throwable cause) {
		super(message, cause);
	}

	public IllegalStrategyException(String message) {
		super(message);
	}

	public IllegalStrategyException(Throwable cause) {
		super(cause);
	}

}
