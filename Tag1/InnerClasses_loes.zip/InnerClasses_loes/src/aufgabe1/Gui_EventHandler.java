package aufgabe1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Gui_EventHandler extends JFrame {

    private class Listener implements ActionListener{
        //Event handling: Listener-Methode
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("blau")) Gui_EventHandler.this.getContentPane().setBackground(Color.BLUE);
            else Gui_EventHandler.this.getContentPane().setBackground(Color.GRAY);
        }
    }

    private JButton blue = new JButton("blau");
    private JButton grey = new JButton("grau");
    private JPanel panel = new JPanel();

    public Gui_EventHandler() throws HeadlessException {
        this.setTitle("MyFrame");
        panel.add(blue);
        panel.add(grey);
        this.add(panel, BorderLayout.SOUTH);
        //Event handling: Listener setzen
        Listener listener = new Listener();
        blue.addActionListener(listener);
        grey.addActionListener(listener);
    }

    public static void main(String[] args) {
        Gui_EventHandler frame = new Gui_EventHandler();
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setSize(200, 200);
        frame.setVisible(true);
    }

}
