/* Aufgabe:
 * Kann die statische Methode über eine nicht-statische Referenz aufgerufen werden?
 * Kann die statische Methode überhaupt über eine implementierende Klasse aufgerufen werden?
 */

package sk.train.aufgabe_static_1;

import java.math.BigDecimal;


public class StaticMethod{
	
	public static void main(String[] args) {
		Modell gm = new ModellImpl(new BigDecimal(5000));
		BigDecimal value = gm.getValue();
		//Verwendung nicht-statischer Referenz ist nicht möglich (anders als bei Klassen)
		//gm.isValidValue(value);
		System.out.println(Modell.isValidValue(value));
		
		//Verwendung statischer Referenz via implementierender Klasse ist auch nicht möglich
		//ModellImpl.isValidValue(value);
		//aber sehr wohl Zugriff auf die statische Konstante
		System.out.println(ModellImpl.MAX_VALUE);
	}	
}

interface Modell
{
	BigDecimal MAX_VALUE = new BigDecimal(1_000_000);

	static boolean isValidValue( BigDecimal value ) {
		return value.compareTo(BigDecimal.ONE) > 0 && value.compareTo(MAX_VALUE) < 0;
	}

	BigDecimal getValue();
}


class ModellImpl implements Modell{

	private BigDecimal value;

	public ModellImpl(BigDecimal value) {
		super();
		this.value = value;
	}

	@Override
	public BigDecimal getValue() {
		return value;
	}
}

