package sk.train.aufgabe_default_1;

interface IF1{
	default void sameMethod() {
		System.out.println("IF1");
	}
}

interface IF2{
	default void sameMethod() {
		System.out.println("IF2");
	}
}
