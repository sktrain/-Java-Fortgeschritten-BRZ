/* Aufgabe:
 * Kann die statische Methode �ber eine nicht-statische Referenz aufgerufen werden?
 * Kann die statische Methode �berhaupt �ber eine implementierende Klasse aufgerufen werden?
 */

package sk.train.aufgabe_static_1;

import java.math.BigDecimal;


public class StaticMethod{
	
	public static void main(String[] args) {
		//todo
	}	
}

interface Modell
{
	BigDecimal MAX_VALUE = new BigDecimal(1_000_000);
	
	static boolean isValidValue( BigDecimal value ) {
	    return value.compareTo(BigDecimal.ONE) > 0 && value.compareTo(MAX_VALUE) < 0;
	  }
	
	BigDecimal getValue();
}


class ModellImpl implements Modell{
	
	private BigDecimal value;
	
	public ModellImpl(BigDecimal value) {
		super();
		this.value = value;
	}

	@Override
	public BigDecimal getValue() {
		return value;
	}
}


