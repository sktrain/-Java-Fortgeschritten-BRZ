package aufgabe1;

import java.util.ArrayList;
import java.util.List;

public class Aufgabe1 {
	
	public static void main(String[] args) {
		List<Person> persons = createDemoData();

		Person person1 = findPersonByName(persons, "unknown");
		processPerson(person1);
		Person person2 = findPersonByName(persons, "Micha");
		processPerson(person2);
	}

	private static void processPerson(Person person) {
		if (person != null) {
			System.out.println(person);
		} else {
			System.out.println("No person found!");
		}
	}

	private static Person findPersonByName(List<Person> persons, String desired) {
		for (Person person : persons) {
			if (person.getName().equals(desired)) {
				return person;
			}
		}
		return null;
	}

	private static List<Person> createDemoData() {
		List<Person> persons = new ArrayList<>();
		persons.add(new Person("Michael", 43));
		persons.add(new Person("Max", 5));
		persons.add(new Person("Moritz", 7));
		persons.add(new Person("Merten", 38));
		persons.add(new Person("Micha", 42));
		return persons;
	}

}
