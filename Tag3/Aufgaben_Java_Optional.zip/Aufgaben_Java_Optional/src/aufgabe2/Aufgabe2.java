package aufgabe2;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import aufgabe1.Person;

public class Aufgabe2 {

	public static void main(String[] args) {
		String result = findInCache("id1");
		if (result != null) System.out.println("found: " + result);
		else {
			result = findInMemory("id1");
			if (result != null) System.out.println("found: " + result);
			else {
				result = findInDb("id1");
				if (result != null) System.out.println("found: " + result);
				else System.out.println("not found");
			}
		}
	}
		

	//Simulation der Suche in verschiedenen Quellen: mal gibt es Treffer, mal nicht (null)	
	
	private static String findInMemory(String customerId) {
		System.out.println("findInMemory");
		return (Math.random() < 0.5) ? null : "Stephan";
	}

	private static String findInCache(String customerId) {
		System.out.println("findInCache");
		return (Math.random() < 0.5) ? null : "Stephan";
	}

	private static String findInDb(String customerId) {
		System.out.println("findInDb");
		return (Math.random() < 0.5) ? null : "Stephan";
	}

}
