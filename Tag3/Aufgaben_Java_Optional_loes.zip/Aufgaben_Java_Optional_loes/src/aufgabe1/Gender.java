package aufgabe1;

public enum Gender
{
    MALE, FEMALE, UNKNOWN;
}