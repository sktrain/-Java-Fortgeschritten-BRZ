package aufgabe1;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Aufgabe1 {

	public static void main(String[] args) {
		List<Person> persons = createDemoData();

		Optional<Person> person1 = findPersonByName(persons, "unknown");
		processPerson(person1);
		processPerson1(person1);
		person1 = findPersonByName(persons, "Micha");
		processPerson(person1);
		processPerson1(person1);
	}

	private static void processPerson(Optional<Person> person) {
		if (person.isPresent()) {
			System.out.println(person.get().getName());
		} else {
			System.out.println("No person found!");
		}
	}
	
	//alternativ ab Java 9
	private static void processPerson1(Optional<Person> person) {
		person.ifPresentOrElse(p -> System.out.println(p.getName()), 
				               () -> System.out.println("No person found!"));
	}

//	private static void processPerson(Person person) {
//		if (person != null) {
//			System.out.println(person);
//		} else {
//			System.out.println("No person found!");
//		}
//	}

	private static Optional<Person> findPersonByName(List<Person> persons, String desired) {
		for (Person person : persons) {
			if (person.getName().equals(desired)) {
				return Optional.of(person);
			}
		}
		return Optional.empty();
	}
	
	
//	private static Person findPersonByName(List<Person> persons, String desired) {
//		for (Person person : persons) {
//			if (person.getName().equals(desired)) {
//				return person;
//			}
//		}
//		return null;
//	}

	private static List<Person> createDemoData() {
		List<Person> persons = new ArrayList<>();
		persons.add(new Person("Michael", 43));
		persons.add(new Person("Max", 5));
		persons.add(new Person("Moritz", 7));
		persons.add(new Person("Merten", 38));
		persons.add(new Person("Micha", 42));
		return persons;
	}

}
