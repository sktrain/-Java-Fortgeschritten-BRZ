package aufgabe2;

import java.util.Optional;
import java.util.stream.Stream;

public class Aufgabe2_loes_a {

	public static void main(final String[] args) {
		Optional<String> opt = findInCache("id1");
		if (opt.isEmpty()) opt = findInMemory("id1");
		if (opt.isEmpty()) opt = findInDb("id1");
		opt.ifPresentOrElse(str -> System.out.println("found: " + str), () -> System.out.println("not found"));
	}

	private static Optional<String> findInMemory(final String customerId) {
		System.out.println("findInMemory");
		return (Math.random() < 0.5) ? Optional.empty() : Optional.of("Stephan");
	}

	private static Optional<String> findInCache(final String customerId) {
		System.out.println("findInCache");
		return (Math.random() < 0.5) ? Optional.empty() : Optional.of("Stephan");
	}

	private static Optional<String> findInDb(final String customerId) {
		System.out.println("findInDb");
		return (Math.random() < 0.5) ? Optional.empty() : Optional.of("Stephan");
	}

}
