package aufgaben_Lambdas_2;

import java.util.Arrays;

public class Aufgabe_7 {

	public static void main(String[] args) {
		int[] original = new int[100];
		
		// a)
		specialFill(original);
		printRange(original, 0, 100);
		
		// b)
		modify(original);
	}

	private static void specialFill(int[] values) {
		//todo
	}
	
	

	private static void printRange(int[] values, int startIdx, int endIdx) {
		for (int i = startIdx; i < endIdx; i++) {
			System.out.print(values[i] + " ");
		}
		System.out.println();
	}
	
	
	private static void modify(int[] values) {
		//todo
	}

}
