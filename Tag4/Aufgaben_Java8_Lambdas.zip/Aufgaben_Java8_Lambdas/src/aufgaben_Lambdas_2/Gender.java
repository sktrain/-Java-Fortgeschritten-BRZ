package aufgaben_Lambdas_2;

public enum Gender
{
    MALE, FEMALE, UNKNOWN;
}