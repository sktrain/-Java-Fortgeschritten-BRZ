package aufgaben_Lambdas_2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Aufgabe_6 {

	public static void main(String[] args) {
		
		List<String> names = createNamesList();
		
		Comparator<String> byLength = null;  //...todo....
		
		Collections.sort(names, byLength);
		System.out.println(names);
	}
	

	private static List<String> createNamesList() {
		final List<String> names = new ArrayList<>();
		names.add("Michael");
		names.add("Tim");
		names.add("J�rg");
		names.add("Flo");
		names.add("Andy");
		names.add("Clemens");
		return names;
	}

}
