package aufgaben_Lambdas_1;

public class Aufgabe_2 {

	public static void main(String[] args) {
		
		final Runnable runner = null;  // ... TODO ...
				
		new Thread(runner).start();
	}

}
